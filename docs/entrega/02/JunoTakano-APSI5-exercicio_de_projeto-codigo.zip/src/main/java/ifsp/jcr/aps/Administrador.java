package ifsp.jcr.aps;

public class Administrador {
  Integer id;
}
