package ifsp.jcr.aps;

public class App {
    public static void main(String[] args) {
        InterfaceUsuario IU = new InterfaceUsuario();
    }
}
