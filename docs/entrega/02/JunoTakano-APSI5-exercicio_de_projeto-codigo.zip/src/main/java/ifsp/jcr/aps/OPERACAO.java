package ifsp.jcr.aps;

public enum OPERACAO {
  INCLUIR,
  LISTAR,
  MATRICULAR,
  BUSCAR,
  EDITAR,
  APAGAR,
  RESPONDER,
}
